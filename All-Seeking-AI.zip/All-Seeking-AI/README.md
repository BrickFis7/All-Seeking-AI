# All-Seeking AI

Type one question, tap **seek all**, and it opens every AI app you picked on your phone with the same query.
Default targets: Claude, ChatGPT, Gemini, Grok. Also built in: Perplexity, Copilot, DeepSeek.

![logo](assets/logo.jpg)

## Build the APK on GitHub (no Android Studio needed)
1. Create a new empty repo on github.com.
2. Upload this project (keep the `.github` folder), or from a terminal:
   `git init && git add . && git commit -m "init" && git branch -M main && git remote add origin <your-repo-url> && git push -u origin main`
3. Open the repo's **Actions** tab. The **Build APK** workflow starts on push (or press **Run workflow**).
4. When it turns green, open the run and download **All-Seeking-AI-apk** under *Artifacts*.
5. Unzip it, copy `app-debug.apk` to your phone, tap it, and allow "install unknown apps" when asked.

## Fixedsys font
Put `fixedsys.ttf` in `app/src/main/assets/fonts/` before building. Otherwise system monospace is used.

## Add another AI app
Add a line to `APPS` in `MainActivity.kt` and its package name to `<queries>` in `AndroidManifest.xml`.

## How it works
Each app gets the query through Android's standard share intent. Whether an app auto-sends or just pre-fills the text is up to that app. The query is also copied to your clipboard as a fallback.
