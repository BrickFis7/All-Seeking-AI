package com.allseeking.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------- palette
private val Bg = Color(0xFF05080D)
private val Panel = Color(0xFF0B1118)
private val Cyan = Color(0xFF00E5FF)
private val Mint = Color(0xFF5CF29A)
private val Dim = Color(0xFF6B8794)
private val Line = Color(0xFF1B2A36)
private val Ink = Color(0xFFD6F6FF)

// ---------------------------------------------------------------- AI apps
// To add an app: append it here AND add its package to <queries> in AndroidManifest.xml.
data class AiApp(val name: String, val pkg: String, val color: Color)

val APPS = listOf(
    AiApp("Claude", "com.anthropic.claude", Color(0xFFE8895F)),
    AiApp("ChatGPT", "com.openai.chatgpt", Color(0xFF19C39A)),
    AiApp("Gemini", "com.google.android.apps.bard", Color(0xFF8AB4F8)),
    AiApp("Grok", "ai.x.grok", Color(0xFFE6E6E6)),
    AiApp("Perplexity", "ai.perplexity.app.android", Color(0xFF20B8CD)),
    AiApp("Copilot", "com.microsoft.copilot", Color(0xFF7C9CFF)),
    AiApp("DeepSeek", "com.deepseek.chat", Color(0xFF4D6BFE)),
)

private const val PREFS = "all_seeking_ai"

fun loadSelection(ctx: Context): Set<String> =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("selected", null)
        ?: APPS.take(4).map { it.pkg }.toSet()

fun saveSelection(ctx: Context, selection: Set<String>) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putStringSet("selected", selection).apply()
}

fun isInstalled(ctx: Context, pkg: String): Boolean =
    try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

/** Copies the query, then opens every selected app with it in one go. Returns a status line. */
fun dispatch(ctx: Context, query: String, apps: List<AiApp>): String {
    val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("query", query))

    val ready = apps.mapNotNull { app ->
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, query)
            setPackage(app.pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (intent.resolveActivity(ctx.packageManager) != null) app to intent else null
    }
    if (ready.isEmpty()) return "> no selected app can receive text.\n> query copied to clipboard."

    return try {
        // One batched launch avoids Android's background-launch block.
        // Last intent ends up on top, so reverse: first app in the list opens first.
        ctx.startActivities(ready.map { it.second }.reversed().toTypedArray())
        val names = ready.joinToString(", ") { it.first.name }
        val missed = apps.size - ready.size
        "> sent to $names" + (if (missed > 0) "\n> skipped $missed (not installed)" else "") +
            "\n> query is also on the clipboard.\n> press back to hop to the next app."
    } catch (e: Exception) {
        "> launch failed: ${e.message}\n> query copied to clipboard."
    }
}

// ---------------------------------------------------------------- UI
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, background = Bg, surface = Panel,
                    surfaceContainer = Panel, onSurface = Ink,
                )
            ) { Screen() }
        }
    }
}

/** Uses assets/fonts/fixedsys.ttf if you add it, otherwise falls back to system monospace. */
@Composable
private fun rememberMono(): FontFamily {
    val ctx = LocalContext.current
    return remember {
        try {
            FontFamily(Typeface.createFromAsset(ctx.assets, "fonts/fixedsys.ttf"))
        } catch (e: Exception) {
            FontFamily.Monospace
        }
    }
}

private fun Modifier.techGrid(): Modifier = drawBehind {
    val step = 32.dp.toPx()
    val c = Line.copy(alpha = 0.45f)
    var x = 0f
    while (x <= size.width) {
        drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f)
        x += step
    }
    var y = 0f
    while (y <= size.height) {
        drawLine(c, Offset(0f, y), Offset(size.width, y), 1f)
        y += step
    }
}

private fun Modifier.brackets(color: Color, len: Dp = 14.dp, stroke: Dp = 2.dp): Modifier = drawBehind {
    val l = len.toPx()
    val s = stroke.toPx()
    val w = size.width
    val h = size.height
    drawLine(color, Offset(0f, 0f), Offset(l, 0f), s); drawLine(color, Offset(0f, 0f), Offset(0f, l), s)
    drawLine(color, Offset(w, 0f), Offset(w - l, 0f), s); drawLine(color, Offset(w, 0f), Offset(w, l), s)
    drawLine(color, Offset(0f, h), Offset(l, h), s); drawLine(color, Offset(0f, h), Offset(0f, h - l), s)
    drawLine(color, Offset(w, h), Offset(w - l, h), s); drawLine(color, Offset(w, h), Offset(w, h - l), s)
}

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    val mono = rememberMono()
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(loadSelection(ctx)) }
    var status by remember { mutableStateOf("> idle. waiting for a question_") }
    val chosen = APPS.filter { it.pkg in selected }

    Box(Modifier.fillMaxSize().background(Bg).techGrid()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Header(mono)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Label("query", mono)
                Label("${query.length} chars", mono)
            }
            Box(Modifier.fillMaxWidth().background(Panel).brackets(Cyan).padding(16.dp)) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    textStyle = TextStyle(fontFamily = mono, fontSize = 16.sp, lineHeight = 23.sp, color = Ink),
                    cursorBrush = SolidColor(Cyan),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 150.dp),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) {
                                Text("> ask every AI at once_", fontFamily = mono, fontSize = 16.sp, color = Dim)
                            }
                            inner()
                        }
                    },
                )
            }

            Label("targets", mono)
            TargetPicker(selected, mono) { pkg ->
                selected = if (pkg in selected) selected - pkg else selected + pkg
                saveSelection(ctx, selected)
            }

            Button(
                onClick = { status = dispatch(ctx, query.trim(), chosen) },
                enabled = query.isNotBlank() && chosen.isNotEmpty(),
                shape = RoundedCornerShape(4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Cyan, contentColor = Bg,
                    disabledContainerColor = Line, disabledContentColor = Dim,
                ),
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) {
                Text("[ seek all ]", fontFamily = mono, fontSize = 18.sp, letterSpacing = 3.sp)
            }

            Text(status, fontFamily = mono, fontSize = 13.sp, lineHeight = 19.sp, color = Cyan)
            Text(
                "no servers. no accounts. your query goes straight to the apps on this phone.",
                fontFamily = mono, fontSize = 11.sp, lineHeight = 16.sp, color = Dim,
            )
        }
    }
}

@Composable
private fun Header(mono: FontFamily) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painterResource(R.drawable.logo_full),
            contentDescription = "All-Seeking AI",
            modifier = Modifier.widthIn(max = 360.dp).fillMaxWidth(),
            contentScale = ContentScale.FillWidth,
        )
        Text("one query, every mind", color = Mint, fontFamily = mono, fontSize = 13.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun Label(text: String, mono: FontFamily) {
    Text("// $text", color = Dim, fontFamily = mono, fontSize = 12.sp, letterSpacing = 1.sp)
}

@Composable
private fun TargetPicker(selected: Set<String>, mono: FontFamily, onToggle: (String) -> Unit) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    val summary = APPS.filter { it.pkg in selected }.joinToString(" + ") { it.name.lowercase() }
        .ifEmpty { "nothing selected" }

    Box {
        Row(
            Modifier.fillMaxWidth().border(1.dp, Line).clickable { open = true }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(summary, Modifier.weight(1f), color = Ink, fontFamily = mono, fontSize = 14.sp, maxLines = 2)
            Text("[${selected.size}/${APPS.size}] v", color = Cyan, fontFamily = mono, fontSize = 14.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, modifier = Modifier.background(Panel)) {
            APPS.forEach { app ->
                val installed = isInstalled(ctx, app.pkg)
                DropdownMenuItem(
                    text = {
                        Text(
                            app.name + if (installed) "" else "  (not installed)",
                            color = if (installed) Ink else Dim, fontFamily = mono,
                        )
                    },
                    leadingIcon = {
                        Checkbox(
                            checked = app.pkg in selected,
                            onCheckedChange = null,
                            colors = CheckboxDefaults.colors(
                                checkedColor = app.color, uncheckedColor = Dim, checkmarkColor = Bg,
                            ),
                        )
                    },
                    onClick = { onToggle(app.pkg) },
                )
            }
        }
    }
}
