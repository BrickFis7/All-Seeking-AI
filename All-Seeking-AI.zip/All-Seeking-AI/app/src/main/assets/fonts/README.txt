Drop your Fixedsys font here and name it exactly:  fixedsys.ttf
(Fixedsys Excelsior is a free community clone.) Without it, the app uses system monospace.
